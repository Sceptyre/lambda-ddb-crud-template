const mItems = require("../models/items")

module.exports = {
    Get(req, res) {

    },
    Put(req, res) {

    },
    Post(req, res) {

    },
    Delete(req, res) {
        try {
            res.status(204).send(mItems.Delete())
        } catch {
            res.status(500).send(
                
            )
        }
    }
}