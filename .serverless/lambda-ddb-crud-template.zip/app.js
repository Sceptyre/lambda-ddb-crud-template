const mwError = require("./middlewares/error" )
const mwLogger = require("./middlewares/logger")

const express = require("express")
const app = express();

app.use(mwLogger)
app.use(mwError)

module.exports = app